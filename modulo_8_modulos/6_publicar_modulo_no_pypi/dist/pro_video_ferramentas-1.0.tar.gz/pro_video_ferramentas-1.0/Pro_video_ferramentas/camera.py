def tirar_foto():
    print('Tirar Foto')